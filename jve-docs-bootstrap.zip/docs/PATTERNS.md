# Patterns

Authoritative quick context: REVIEW_CACHE.md

## Lua conventions
- TBD

## Subsystem idioms
- core/
- models/
- ui/
- qt_bindings/
- inspectable/
- importers/
- media/
- bug_reporter/
