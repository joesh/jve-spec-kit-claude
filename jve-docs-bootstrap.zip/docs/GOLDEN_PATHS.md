# Golden Paths

Authoritative quick context: REVIEW_CACHE.md

## Run unit tests
- TBD (expected success: all pass)

## Run integration tests
- TBD

## Capture workflows
- TBD

(Commands must include expected success signals or be marked UNVERIFIED.)
