# Traps

Authoritative quick context: REVIEW_CACHE.md

Format:
- Symptoms
- Root cause
- Avoidance
- Detection
- Related invariants / ENGINEERING rules

## TRAP-001
- TBD
