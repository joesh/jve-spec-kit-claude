# Evidence Index

Authoritative quick context: REVIEW_CACHE.md

## Read first (5–15 files)
- TBD

## Test taxonomy
- unit: tests/unit/
- integration: tests/integration/
- captures: tests/captures/
- ad_hoc: tests/ad_hoc/
- helpers: tests/helpers/

## Entry points
- TBD

## Hot zones
- TBD
