# REVIEW CACHE (Authoritative, hard cap: ≤ 50 lines)

Rules:
- Bullets only. No prose.
- Every bullet must point to a canonical doc section.
- If adding exceeds 50 lines, merge or delete older bullets.

## Confirmed invariants
- (empty)

## Known violations / debt
- (empty)

## Hot zones
- (empty)

## Accepted structural decisions
- (empty)
