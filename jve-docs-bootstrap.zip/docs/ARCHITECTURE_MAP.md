# Architecture Map

Authoritative quick context: REVIEW_CACHE.md

## Module boundaries
- TBD

## Data flow
- TBD

## Layering rules
- Enforced by ENGINEERING.md §1.10, §2.18
