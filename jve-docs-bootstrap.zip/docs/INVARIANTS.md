# Invariants

Authoritative quick context: REVIEW_CACHE.md

Format per invariant:
- ID
- Statement
- Evidence (file/symbol)
- How to verify
- Related ENGINEERING rule IDs

## INV-001
- TBD
