#!/usr/bin/env bash
set -euo pipefail

CODEX_BIN="${CODEX_BIN:-codex}"

PROMPT_FILE="prompts/INCREMENTAL_REVIEW.md"
PASS_FILE="prompts/baseline_passes.txt"

usage() {
  echo "Usage:" >&2
  echo "  $0 --uncommitted" >&2
  echo "  $0 --commit <sha>" >&2
  echo "  $0 --base <branch>" >&2
  exit 1
}

if (( $# < 1 )); then
  usage
fi

MODE=""
MODE_ARG=""

case "$1" in
  --uncommitted)
    MODE="--uncommitted"
    ;;
  --commit)
    [[ $# -eq 2 ]] || usage
    MODE="--commit"
    MODE_ARG="$2"
    ;;
  --base)
    [[ $# -eq 2 ]] || usage
    MODE="--base"
    MODE_ARG="$2"
    ;;
  *)
    usage
    ;;
esac

# Repo-root sanity check
if [[ ! -f ENGINEERING.md || ! -f DEVELOPMENT-PROCESS.md || ! -d src || ! -d tests || ! -d docs ]]; then
  echo "ERROR: Must be run from repo root (ENGINEERING.md, DEVELOPMENT-PROCESS.md, src/, tests/, docs/ must exist)" >&2
  exit 1
fi

if [[ ! -f "$PROMPT_FILE" ]]; then
  echo "Missing prompt file: $PROMPT_FILE" >&2
  exit 1
fi

if [[ ! -f "$PASS_FILE" ]]; then
  echo "Missing pass definition file: $PASS_FILE" >&2
  exit 1
fi

# Enable globstar for ** expansion and nullglob so we can detect empty matches
shopt -s globstar nullglob

while IFS='|' read -r pass_name pass_paths; do
  [[ -z "${pass_name// }" ]] && continue
  [[ "$pass_name" =~ ^# ]] && continue

  pass_name="$(echo "$pass_name" | xargs)"
  pass_paths="$(echo "$pass_paths" | xargs)"

  # Sanity check: each glob must match at least one path
  for pattern in $pass_paths; do
    matches=( $pattern )
    if (( ${#matches[@]} == 0 )); then
      echo "ERROR: Pass '$pass_name' glob matches nothing: $pattern" >&2
      exit 1
    fi
  done

  echo
  echo "=== INCREMENTAL REVIEW: $pass_name ==="
  echo "Mode: $MODE ${MODE_ARG:-}"
  echo "Scope: $pass_paths"
  echo

  scope_block="Subsystem scope:
- ${pass_paths// /$'\n- '}"

  prompt="$(cat "$PROMPT_FILE"; echo; echo "$scope_block")"

  if [[ "$MODE" == "--uncommitted" ]]; then
    "$CODEX_BIN" review --uncommitted "$prompt"
  elif [[ "$MODE" == "--commit" ]]; then
    "$CODEX_BIN" review --commit "$MODE_ARG" "$prompt"
  else
    "$CODEX_BIN" review --base "$MODE_ARG" "$prompt"
  fi

done < "$PASS_FILE"
