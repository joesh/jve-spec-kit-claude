#!/usr/bin/env bash
set -euo pipefail

BASE_BRANCH="${BASE_BRANCH:-main}"
CODEX_BIN="${CODEX_BIN:-codex}"

PROMPT_FILE="prompts/BASELINE_MASTER_REVIEW.md"
PASS_FILE="prompts/baseline_passes.txt"

# Repo-root sanity check
if [[ ! -f ENGINEERING.md || ! -f DEVELOPMENT-PROCESS.md || ! -d src || ! -d tests || ! -d docs ]]; then
  echo "ERROR: Must be run from repo root (ENGINEERING.md, DEVELOPMENT-PROCESS.md, src/, tests/, docs/ must exist)" >&2
  exit 1
fi

if [[ ! -f "$PROMPT_FILE" ]]; then
  echo "Missing prompt file: $PROMPT_FILE" >&2
  exit 1
fi

if [[ ! -f "$PASS_FILE" ]]; then
  echo "Missing pass definition file: $PASS_FILE" >&2
  exit 1
fi

# Enable globstar for ** expansion and nullglob so we can detect empty matches
shopt -s globstar nullglob

while IFS='|' read -r pass_name pass_paths; do
  # Skip comments and blank lines
  [[ -z "${pass_name// }" ]] && continue
  [[ "$pass_name" =~ ^# ]] && continue

  pass_name="$(echo "$pass_name" | xargs)"
  pass_paths="$(echo "$pass_paths" | xargs)"

  # Sanity check: each glob must match at least one path
  for pattern in $pass_paths; do
    matches=( $pattern )
    if (( ${#matches[@]} == 0 )); then
      echo "ERROR: Pass '$pass_name' glob matches nothing: $pattern" >&2
      exit 1
    fi
  done

  echo
  echo "=== BASELINE REVIEW: $pass_name ==="
  echo "Scope: $pass_paths"
  echo

  scope_block="Subsystem scope:
- ${pass_paths// /$'\n- '}"

  "$CODEX_BIN" review --base "$BASE_BRANCH"     "$(cat "$PROMPT_FILE"; echo; echo "$scope_block")"

done < "$PASS_FILE"
